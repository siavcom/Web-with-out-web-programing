<template>
  <div class="error">
    <h1>Ruta no encontrada</h1>
  </div>
</template>
